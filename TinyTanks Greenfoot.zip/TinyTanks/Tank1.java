import greenfoot.*; // Greenfoot-Bibliothek importieren

public class Tank1 extends Actor {
    private int richtung; // 0 = oben, 1 = rechts, 2 = unten, 3 = links
    int repeat;
    public Tank1() {
        this.richtung = 0;
        repeat=2;// Startet nach oben gerichtet
    }

    public void act() {
        // �berpr�fe die Tasten und bewege den Tank
        if (Greenfoot.isKeyDown("w")) {
            bewegeNachVorn();
        }
          if (Greenfoot.isKeyDown("s")) {
            bewegeNachHinten();
        }
        if (Greenfoot.isKeyDown("d")) {
            dreheNachRechts();
        }
        if (Greenfoot.isKeyDown("a")) {
            dreheNachLinks();
        }
    }

    // Bewegung nach vorn
    public void bewegeNachVorn() {
        for(int i = 0; i < repeat; i++) {
        move(9);
    }// Bewegt sich 5 Pixel in die aktuelle Richtung
    }
     // R�ckw�rtsbewegung mit Repeat-Faktor und Pause
    public void bewegeNachHinten() {
        for (int i = 0; i < repeat; i++) {
            move(-9); // Bewegt sich 5 Pixel r�ckw�rts
        }
    }
    // Drehung nach rechts
    public void dreheNachRechts() {
        for(int i = 0; i < repeat; i++) {
         turn(15); // Dreht um 90 Grad nach rechts
    }
        
    }

    // Drehung nach links
    public void dreheNachLinks() {
         for(int i = 0; i < repeat; i++) {
         turn(-15); // Dreht um 90 Grad nach links
    }
    }
}
