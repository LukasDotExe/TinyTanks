import greenfoot.*; // Greenfoot-Bibliothek importieren

public class TankWorld extends World {
    public TankWorld() {
        super(600, 400, 1); 
        setBackground(new GreenfootImage("4.jpg"));// Erstelle eine Welt mit 600x400 Pixeln und Zellengr��e 1
        Tank1 tank1 = new Tank1();
        addObject(tank1, 50, 200);
        Tank2 tank2 = new Tank2();
        addObject(tank2, 550, 200); // F�ge Tank1 in der Mitte der Welt hinzu
    // Spawne eine Wand an einer zuf�lligen Position
    for (int i = 0; i < 3; i++) {
        spawnRandomWand();
        }
     }
    // Methode zum zuf�lligen Spawnen einer Wand
    public void spawnRandomWand() {
        int x = Greenfoot.getRandomNumber(getWidth());  // Zuf�llige X-Position (zwischen 0 und der Breite der Welt)
        int y = Greenfoot.getRandomNumber(getHeight()); // Zuf�llige Y-Position (zwischen 0 und der H�he der Welt)
        
        // Wand erstellen und an zuf�llige Position setzen
        Wand wand = new Wand();
        addObject(wand, x, y);  // Wand an der zuf�lligen Position platzieren
    }
}
