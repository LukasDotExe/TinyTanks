import greenfoot.*;  

public class Wand extends Actor {
    public Wand() {
        // Originalbild der Wand laden
        GreenfootImage bild = new GreenfootImage("brick.PNG");
        
        // Bild auf eine kleinere Gr��e skalieren (z. B. 40x40 Pixel)
        bild.scale(120, 40); // Breite und H�he in Pixeln
        setImage(bild); // Setze das skalierte Bild als Wand-Bild
         turn(90);
    }
}
