import greenfoot.*;  

public class Wand extends Actor {
    public Wand() {
        // Originalbild der Wand laden
        GreenfootImage bild = new GreenfootImage("brick.jpg");
        
        // Bild auf eine kleinere Größe skalieren (z. B. 40x40 Pixel)
        bild.scale(100, 30); // Breite und Höhe in Pixeln
        setImage(bild); // Setze das skalierte Bild als Wand-Bild
         turn(90);
    }
}