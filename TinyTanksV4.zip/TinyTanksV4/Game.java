import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Game extends World{
int player;
    public Game(int _player){    
        super(16*64, 9*64, 1);
        player = _player;
        if(player == 1){
            addObject(new Tank(this,1),64,64);
            SpawnTargets();
        }else{
            addObject(new Tank(this,1),64,64);
            addObject(new Tank2(this,2),15*64,8*64);
        }
         for (int i = 0; i < 1; i++) {
            spawnWalls(); 
        }
    }

    public void spawnWallInCenter() {
    // Weltgröße
    int worldWidth = getWidth();
    int worldHeight = getHeight();

    // Abstand von einem Viertel der Weltbreite/-höhe vom Rand
    int marginX = worldWidth / 4;
    int marginY = worldHeight / 4;

    // Grenzen für die mittlere Zone
    int centerXStart = marginX;                 // Beginn der Zone in X-Richtung
    int centerXEnd = worldWidth - marginX;      // Ende der Zone in X-Richtung
    int centerYStart = marginY;                 // Beginn der Zone in Y-Richtung
    int centerYEnd = worldHeight - marginY;     // Ende der Zone in Y-Richtung

    boolean placed = false; // Wurde die Wand erfolgreich platziert?
    int maxAttempts = 20;   // Maximale Anzahl an Versuchen, um eine Position zu finden
    int attempts = 0;

    while (!placed && attempts < maxAttempts) {
        // Zufällige Position innerhalb der definierten Zone
        int x = Greenfoot.getRandomNumber(centerXEnd - centerXStart) + centerXStart;
        int y = Greenfoot.getRandomNumber(centerYEnd - centerYStart) + centerYStart;

        // Prüfe, ob sich an der Position bereits eine Wand befindet
        if (getObjectsAt(x, y, Wand.class).isEmpty()) {
            // Erstelle eine Wand und füge sie an der berechneten Position hinzu
            Wand wand = new Wand();
            addObject(wand, x, y);
            placed = true; // Platzierung erfolgreich
        }

        attempts++;
    }
       
} 
    public void SpawnTargets() {
      int worldHeight = getHeight(); // Höhe des Spiels ermitteln
        int spacing = worldHeight / 4; // Berechnet den Abstand zwischen den Targets (1/4 der Höhe)

    // Erstelle und platziere die Targets
    for (int i = 1; i <= 3; i++) {
        // Y-Position berechnen, um gleichmäßigen Abstand zu schaffen
        int yPosition = i * spacing;

        // Erstelle ein neues Target-Objekt
        Target target = new Target();
        
        // Füge das Target am rechten Bildschirmrand hinzu (x = Weltbreite - 1 für den äußersten Rand)
        addObject(target, getWidth() - 1, yPosition); 
    }    
}
    public void spawnWalls() {
    // Berechne die Mitte der Map
    int centerX = getWidth() / 2;
    int centerY = getHeight() / 2;
    
    // Spawnpositionen für die Wände
    // 200px von der oberen rechten Ecke auf der X-Koordinate
    int wall1X = getWidth() - 200;
    int wall1Y = getHeight() - 100;
    
    // 200px von der unteren linken Ecke auf der Y-Koordinate
    int wall2X = 200;
    int wall2Y = 100;
    
    // Wand in der Mitte der Map
    int wall3X = centerX;
    int wall3Y = centerY;
    
    int wall4X = 700;
    int wall4Y = 100;
    
    int wall5X = 300;
    int wall5Y = 500;

    // Erstelle und platziere die Wände
    addObject(new Wand(), wall1X, wall1Y);  
    addObject(new Wand(), wall2X, wall2Y);  
    addObject(new Wand(), wall3X, wall3Y);  
    addObject(new Wand(), wall4X, wall4Y);  
    addObject(new Wand(), wall5X, wall5Y);  
}
}
