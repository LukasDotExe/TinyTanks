    import greenfoot.*;
    
    public class Projectile extends Actor {
        int rotation_;
        Game game;
        int bounce;
        public Projectile(int rot, Game game_){
            rotation_ = rot;
            setRotation(rot);
            game = game_;
            bounce = 0;
            GreenfootImage image = getImage();
            image.scale(64,32);
        }
    
        public void act(){
            if(bounce == 3){
                game.removeObject(this);
                return;
            }
            double rotation = Math.toRadians(rotation_);
            setLocation(getX() + (int) Math.round(Math.cos(rotation) * 6), getY() + (int) Math.round(Math.sin(rotation) * 6));
            if (isTouching(Target.class)) {
            // Entferne das Target
            Actor target = getOneIntersectingObject(Target.class);
            if (target != null) {
                getWorld().removeObject(target);
            }
            
            // Entferne die Bullet
            game.removeObject(this);
            return; // Stoppe die weitere Verarbeitung
            }
            if(getX() >= game.getWidth() - 5 || getX() <= 5){
                rotation_ = 180 - rotation_;
                setRotation(rotation_);
                bounce++;
            }
            if(getY() >= game.getHeight() - 5 || getY() <= 5){
                rotation_ = -1 * rotation_;
                setRotation(rotation_);
                bounce++;
            }
            // Wand-Kollision prüfen
            if (isTouching(Wand.class)) {
            wallbounce();
            }
        }
        
         public void wallbounce() {
            // Ermittelt die Wand, mit der die Kugel kollidiert
            Actor wall = getOneIntersectingObject(Wand.class);
            if (wall != null) {
            // Differenzen berechnen
            int dx = getX() - wall.getX();
            int dy = getY() - wall.getY();

            // Abprallrichtung bestimmen
            if (Math.abs(dx) > Math.abs(dy)) {
                // Horizontale Kollision
                rotation_ = 180 - rotation_;
            } else {
                // Vertikale Kollision
                rotation_ = -1 * rotation_;
            }
            setRotation(rotation_);
            bounce++;
            }
        }
}
