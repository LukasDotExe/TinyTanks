import greenfoot.*;

public class Tank2 extends Actor {
    int i = 0;
    Game game;
    public Tank2(Game game_, int player){
        game = game_;
        if(player == 2){
            setImage("images/tank_blue.png");
        }
    }

    public void act(){
        int originalX = getX();
        int originalY = getY();
        double rotation = Math.toRadians(getRotation());
        if(Greenfoot.isKeyDown("up")) {
            setLocation(getX() + (int) Math.round(Math.cos(rotation) * 5), getY() + (int) Math.round(Math.sin(rotation) * 5));
        }
        if(Greenfoot.isKeyDown("down")) {
            setLocation(getX() - (int) Math.round(Math.cos(rotation) * 5), getY() - (int) Math.round(Math.sin(rotation) * 5));
        }
        if(Greenfoot.isKeyDown("right")) {
            turn(5);
        }
        if(Greenfoot.isKeyDown("left")) {
            turn(-5);
        }
        if(i == 100){
            game.addObject(new Projectile(getRotation(),game),getX(),getY());
            i = 0;
        }
        else{i++;}
        if (isTouching(Wand.class)) {
        // Wenn ja, Bewegung rückgängig machen
        setLocation(originalX, originalY);
        }
    }
    
    
}
