import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Main extends World{
    Text pointer = new Text(">");
    int player = 1;
    public Main(){    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(16*64,9*64, 1);
        prepare();
    }
    private void prepare(){
        addObject(new Text("TinyTanks","Aptos",80),2*64+400,2*64);
        addObject(new Text("Press Enter to start a new Game"),2*64+400,4*64);
        addObject(new Text("One Player"),3*64+400,5*64);
        addObject(new Text("Two Players"),3*64+400,6*64);
        addObject(pointer,2*64+400,5*64);
    }
    
    public void act(){
        if(Greenfoot.isKeyDown("up")||Greenfoot.isKeyDown("down")){
            if(player == 1){
                pointer.setLocation(2*64+400,6*64);
                player = 2;
            }
            else{
                pointer.setLocation(2*64+400,5*64);
                player = 1;
            }
            Greenfoot.delay(10);
        }
        if(Greenfoot.isKeyDown("Enter")){
            Game game = new Game(player);
            Greenfoot.setWorld(game);
        }
    }
}
