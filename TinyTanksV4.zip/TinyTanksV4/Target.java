import greenfoot.*;
public class Target extends Actor {
    public Target() {
        // Hole das Bild des Targets
        GreenfootImage image = getImage();
        
        // Skaliere das Bild (z.B. verdoppeln der Größe)
        image.scale(100, 100);  // Ändere die Werte, um die gewünschte Größe zu erreichen
    }

    public void act() {
        // Hier kommt der Code für das Verhalten des Targets
    }
}
