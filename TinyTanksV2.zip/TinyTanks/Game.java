import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Game extends World{
int player;
    public Game(int _player){    
        super(16*64, 9*64, 1);
        player = _player;
        if(player == 1)
            addObject(new Tank(this,1),64,64);
        else{
            addObject(new Tank(this,1),64,64);
            addObject(new Tank2(this,2),15*64,8*64);
        }
         for (int i = 0; i < 4; i++) {
            spawnWallInCenter();
        }
    }

    public void spawnWallInCenter() {
    // Weltgröße
    int worldWidth = getWidth();
    int worldHeight = getHeight();

    // Abstand von einem Viertel der Weltbreite/-höhe vom Rand
    int marginX = worldWidth / 5;
    int marginY = worldHeight / 5;

    // Grenzen für die mittlere Zone
    int centerXStart = marginX;                 // Beginn der Zone in X-Richtung
    int centerXEnd = worldWidth - marginX;      // Ende der Zone in X-Richtung
    int centerYStart = marginY;                 // Beginn der Zone in Y-Richtung
    int centerYEnd = worldHeight - marginY;     // Ende der Zone in Y-Richtung

    boolean placed = false; // Wurde die Wand erfolgreich platziert?
    int maxAttempts = 20;   // Maximale Anzahl an Versuchen, um eine Position zu finden
    int attempts = 0;

    while (!placed && attempts < maxAttempts) {
        // Zufällige Position innerhalb der definierten Zone
        int x = Greenfoot.getRandomNumber(centerXEnd - centerXStart) + centerXStart;
        int y = Greenfoot.getRandomNumber(centerYEnd - centerYStart) + centerYStart;

        // Prüfe, ob sich an der Position bereits eine Wand befindet
        if (getObjectsAt(x, y, Wand.class).isEmpty()) {
            // Erstelle eine Wand und füge sie an der berechneten Position hinzu
            Wand wand = new Wand();
            addObject(wand, x, y);
            placed = true; // Platzierung erfolgreich
        }

        attempts++;
    }
   
} 
}
