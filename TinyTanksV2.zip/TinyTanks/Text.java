import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class startText here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Text extends Actor{
    
    public Text(String str){
        GreenfootImage text = new GreenfootImage(800,200);
        text.setFont(new Font("Aptos",40));
        text.drawString(str,0,100);
        setImage(text);
    }
    
    public Text(String str, String font, int fsize){
        GreenfootImage text = new GreenfootImage(800,200);
        text.setFont(new Font(font,fsize));
        text.drawString(str,0,100);
        setImage(text);
    }
}
