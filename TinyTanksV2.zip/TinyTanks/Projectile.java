import greenfoot.*;

public class Projectile extends Actor {
    int rotation_;
    Game game;
    int bounce;
    public Projectile(int rot, Game game_){
        rotation_ = rot;
        setRotation(rot);
        game = game_;
        bounce = 0;
        GreenfootImage image = getImage();
        image.scale(64,32);
    }

    public void act(){
        if(bounce == 3){
            game.removeObject(this);
            return;
        }
        double rotation = Math.toRadians(rotation_);
        setLocation(getX() + (int) Math.round(Math.cos(rotation) * 6), getY() + (int) Math.round(Math.sin(rotation) * 6));
        if(getX() >= game.getWidth() - 5 || getX() <= 5){
            rotation_ = 180 - rotation_;
            setRotation(rotation_);
            bounce++;
        }
        if(getY() >= game.getHeight() - 5 || getY() <= 5){
            rotation_ = -1 * rotation_;
            setRotation(rotation_);
            bounce++;
        }
    }
    
    
}
